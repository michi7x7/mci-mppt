/*##############################################################################

	Name	: USI TWI Slave driver - I2C/TWI-EEPROM
	Version	: 1.3  - Stable
	autor	: Martin Junghans	jtronics@gmx.de
	page	: www.jtronics.de
	License	: GNU General Public License 

	Created from Atmel source files for Application Note AVR312: 
  Using the USI Module as an I2C slave like a I2C-EEPROM.
  
//############################################################################*/
#ifndef F_CPU
#define F_CPU 8000000UL
#endif

#define READ 1
#define WRITE 0

#include <avr/interrupt.h>

#include <util/delay.h>
#include <inttypes.h>

#define TWI_GEN_CALL 0x04 //Slave Address
#include "usiTwiMaster.h"

const uint8_t MAX_WRITE_ADDR = 0xE0;
const uint8_t MAX_READ_ADDR = 0xE1;

const uint8_t REG_TMP = 0x08;



void sendToSlave(uint16_t);
uint16_t readTemp(void);
volatile unsigned char state = 0; //Default State

int main(void) {
	DDRA = 0xFF;
	//PORTA = 0x7F;
	uint16_t temp;
    USI_TWI_Master_Initialise();
	PORTA = 0;
	
        while(1){
			_delay_ms(2000);
			PORTA = 0;
			//PORTA &= ~0x3F;
			_delay_ms(2000);
			temp = readTemp();
			PORTA = ~state;
			_delay_ms(1000);
			PORTA = 0;
			sendToSlave(temp);
			PORTA = state;
		}
		

        return 1;
}

void sendToSlave(uint16_t temp) {
        unsigned char messageBuf[3];
		messageBuf[0] = (TWI_GEN_CALL << 1);
		messageBuf[1] = temp >> 8;
		messageBuf[2] = temp;
		
		unsigned char success = USI_TWI_Start_Transceiver_With_Data( messageBuf, 3 );
		if (!success) {
                USI_TWI_Master_Initialise();
				
                switch(USI_TWI_Get_State_Info( )) {

                case USI_TWI_NO_DATA:             // Transmission buffer is empty
                        state = 1;
                        break;
                case USI_TWI_DATA_OUT_OF_BOUND:   // Transmission buffer is outside SRAM space
                        state = 2;
                        break;
                case USI_TWI_UE_START_CON:        // Unexpected Start Condition
                        state = 3;
                        break;
                case USI_TWI_UE_STOP_CON:        // Unexpected Stop Condition
                        state = 4;
                        break;
                case USI_TWI_UE_DATA_COL:         // Unexpected Data Collision (arbitration)
                        state = 5;
                        break;
                case USI_TWI_NO_ACK_ON_DATA:      // The slave did not acknowledge  all data
                        state = 6;
                        break;
                case USI_TWI_NO_ACK_ON_ADDRESS:   // The slave did not acknowledge  the address
                        state = 7;
                        break;
                case USI_TWI_MISSING_START_CON:   // Generated Start Condition not detected on bus
                        state = 8;
                        break;
                case USI_TWI_MISSING_STOP_CON:    // Generated Stop Condition not detected on bus
                        state = 9;
                        break;
                }
       }
}


uint16_t readTemp() {
	
	unsigned char message[3];
	unsigned char success;
	message[0] = MAX_WRITE_ADDR;
		message[1] = 0x0A; // CTRL Register 1
		message[2] = 0x06; // Read Die TEMP
	
	success = USI_TWI_Start_Transceiver_With_Data( message, 3 ); // set register
	
message[0] = MAX_WRITE_ADDR;
message[1] = REG_TMP;
	
	success = USI_TWI_Start_Transceiver_With_Data(message, 2); // set register
	
	
	
		message[0] = MAX_READ_ADDR;
		message[1] = 0x0;
		
		success = USI_TWI_Start_Transceiver_With_Data( message, 2 ); // start read
	
	uint16_t temp = message[0]<<8 | message[1];
	
	if (!success) {
		USI_TWI_Master_Initialise();
		
		switch(USI_TWI_Get_State_Info( )) {

			case USI_TWI_NO_DATA:             // Transmission buffer is empty
			state = 1;
			break;
			case USI_TWI_DATA_OUT_OF_BOUND:   // Transmission buffer is outside SRAM space
			state = 2;
			break;
			case USI_TWI_UE_START_CON:        // Unexpected Start Condition
			state = 3;
			break;
			case USI_TWI_UE_STOP_CON:        // Unexpected Stop Condition
			state = 4;
			break;
			case USI_TWI_UE_DATA_COL:         // Unexpected Data Collision (arbitration)
			state = 5;
			break;
			case USI_TWI_NO_ACK_ON_DATA:      // The slave did not acknowledge  all data
			state = 6;
			break;
			case USI_TWI_NO_ACK_ON_ADDRESS:   // The slave did not acknowledge  the address
			state = 7;
			break;
			case USI_TWI_MISSING_START_CON:   // Generated Start Condition not detected on bus
			state = 8;
			break;
			case USI_TWI_MISSING_STOP_CON:    // Generated Stop Condition not detected on bus
			state = 9;
			break;
		}
		

	}
			return temp;
}